﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Domain.DomainModels
{
    public class Review : BaseEntity
    {
        [ForeignKey(nameof(Recipe))]
        public Guid? RecipeId { get; set; }
        public Recipe? Recipe { get; set; }

        public string? UserId { get; set; }
        public string UserName { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
