﻿using RecipeBook.Domain.DomainModels;



namespace RecipeBook.Service.Interface
{
    public interface IUserService
    {
        List<User> GetAll();
        User? GetById(string id);
    }
}
