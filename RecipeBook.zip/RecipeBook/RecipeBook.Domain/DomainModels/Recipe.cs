﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Domain.DomainModels
{
    public class Recipe : BaseEntity
    {
        [Required]
        public string Name { get; set; }

        public string Category { get; set; }
        public string Area { get; set; }

        public string Instructions { get; set; }
        public string ThumbnailUrl { get; set; }

        public ICollection<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public ICollection<Review> Reviews { get; set; } = new List<Review>();
        public ICollection<FavouriteRecipe> FavouriteRecipes { get; set; } = new List<FavouriteRecipe>();
        public ICollection<SharedRecipe> SharedRecipes { get; set; } = new List<SharedRecipe>();
    }
}
