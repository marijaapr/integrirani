﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Domain.DomainModels
{
    public class SharedRecipe : BaseEntity
    {
        [ForeignKey(nameof(Recipe))]
        public Guid RecipeId { get; set; }
        public Recipe Recipe { get; set; }

        public string SharedWithUserId { get; set; }
        public string SharedByUserId { get; set; }

        public ShareStatus Status { get; set; } = ShareStatus.Pending;
        public DateTime SharedAt { get; set; } = DateTime.UtcNow;
    }

    public enum ShareStatus
    {
        Pending,
        Accepted,
        Declined
    }
}
