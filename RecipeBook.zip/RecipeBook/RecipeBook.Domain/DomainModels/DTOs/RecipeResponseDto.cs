﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Domain.DomainModels.DTOs
{
    public class RecipeResponseDto
    {
        public List<RecipeDto> Meals { get; set; }
    }
}
