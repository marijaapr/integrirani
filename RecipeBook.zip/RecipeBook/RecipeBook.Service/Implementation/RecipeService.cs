﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository;
using RecipeBook.Repository.Interface;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace RecipeBook.Service.Implementation
{
    public class RecipeService : IRecipeService
    {
        private readonly IRepository<Recipe> _recipeRepository;
        private readonly IRepository<Review> _reviewRepository;

        public RecipeService(IRepository<Recipe> recipeRepository, IRepository<Review> reviewRepository)
        {
            _recipeRepository = recipeRepository;
            _reviewRepository = reviewRepository;
        }

        public List<Recipe> GetAll()
        {
             
            return _recipeRepository.GetAll(
                include: query => query
                    .Include(r => r.Ingredients)
                    .Include(r => r.Reviews))
                .ToList();
        }

        public Recipe GetById(Guid id)
        {
            return _recipeRepository.Get(
                predicate: r => r.Id == id,
                include: query => query
                    .Include(r => r.Ingredients)
                    .Include(r => r.Reviews));
        }

        public Recipe Create(Recipe recipe)
        {
            if (recipe.Id == Guid.Empty)
                recipe.Id = Guid.NewGuid();

            return _recipeRepository.Insert(recipe);
        }

        public Recipe Update(Recipe recipe)
        {
            return _recipeRepository.Update(recipe);
        }

        public Recipe Delete(Guid id)
        {
            var recipe = _recipeRepository.Get(predicate: r => r.Id == id);
            if (recipe == null)
                throw new ArgumentException($"Recipe with id {id} not found.");

            return _recipeRepository.Delete(recipe);
        }

        public List<Recipe> GetTopRated(int minRating)
        {
            // Враќаме рецепти кои имаат просечна оцена поголема или еднаква на minRating
            var recipes = _recipeRepository.GetAll(include: q => q.Include(r => r.Reviews));

            return recipes
                .Where(r => r.Reviews.Any())
                .Where(r => r.Reviews.Average(rv => rv.Rating) >= minRating)
                .ToList();
        }

        public List<Recipe> SearchByName(string name)
        {
            return _recipeRepository.GetAll(
                predicate: r => r.Name.Contains(name),
                include: query => query.Include(r => r.Ingredients))
                .ToList();
        }

        public double GetAverageRating(Guid recipeId)
        {
            var reviews = _reviewRepository.GetAll(predicate: r => r.RecipeId == recipeId);

            if (!reviews.Any())
                return 0;

            return reviews.Average(r => r.Rating);
        }
    }
}
