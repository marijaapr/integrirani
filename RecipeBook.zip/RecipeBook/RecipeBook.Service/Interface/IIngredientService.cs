﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface IIngredientService
    {
        List<Ingredient> GetAllByRecipe(Guid recipeId);
        Ingredient GetById(Guid id);
        Ingredient Create(Ingredient ingredient);
        Ingredient Update(Ingredient ingredient);
        Ingredient Delete(Guid id);
    }
}
