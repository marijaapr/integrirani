﻿using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System.Collections.Generic;

namespace RecipeBook.Web.Controllers
{
    public class UsersController : Controller
    {
        private readonly IUserService _userService;

        public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        // GET: /User
        public IActionResult Index()
        {
            List<User> users = _userService.GetAll();
            return View(users);
        }

        // GET: /User/Details/5
        public IActionResult Details(string id)
        {
            if (string.IsNullOrEmpty(id))
                return NotFound();

            var user = _userService.GetById(id);
            if (user == null)
                return NotFound();

            return View(user);
        }
    }
}
