﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RecipeBook.Domain.DomainModels;


namespace RecipeBook.Repository.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Recipe> Recipes { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<FavouriteRecipe> FavouriteRecipes { get; set; }
        public DbSet<SharedRecipe> SharedRecipes { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            
            builder.Entity<SharedRecipe>(entity =>
            {
                // Корисник кој го прима рецептот (SharedWithUser)
                entity.HasOne<User>()
                    .WithMany(u => u.SharedRecipesReceived)
                    .HasForeignKey(sr => sr.SharedWithUserId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Корисник кој го споделил рецептот (SharedByUser)
                entity.HasOne<User>()
                    .WithMany(u => u.SharedRecipesSent)
                    .HasForeignKey(sr => sr.SharedByUserId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            
        }
    }
}
