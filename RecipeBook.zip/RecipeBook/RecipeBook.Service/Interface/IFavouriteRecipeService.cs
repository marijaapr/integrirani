﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface IFavouriteRecipeService
    {
        List<FavouriteRecipe> GetFavouritesForUser(string userId);
        FavouriteRecipe AddToFavourites(string userId, Guid recipeId);
        bool RemoveFromFavourites(string userId, Guid recipeId);
    }
}
