﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface IDataFetchService
    {

        Task<Recipe?> FetchAndSaveRecipeByNameAsync(string name);

        
        Task<List<Recipe>> FetchAndSaveRecipesAsync(string? category = null, string? area = null);
    }
}
