﻿namespace RecipeBook.Domain
{
    public class Class1
    {

    }
}
