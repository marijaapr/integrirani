﻿using Microsoft.EntityFrameworkCore;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository.Data;
using RecipeBook.Repository.Interface;

using System.Collections.Generic;
using System.Linq;

namespace RecipeBook.Repository.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly ApplicationDbContext _context;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<User> GetAll()
        {
            return _context.Users.ToList();
        }

        public User? GetById(string id)
        {
            return _context.Users.Find(id);
        }

        public User? GetByUserName(string username)
        {
            return _context.Users.SingleOrDefault(u => u.UserName == username);
        }

        public User? GetByEmail(string email)
        {
            return _context.Users.SingleOrDefault(u => u.Email == email);
        }
    }
}
