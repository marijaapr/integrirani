﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface ISharedRecipeService
    {
        List<SharedRecipe> GetSharedRecipesForUser(string userId);
        SharedRecipe ShareRecipe(Guid recipeId, string sharedByUserId, string sharedWithUserId);
        bool AcceptShare(Guid sharedRecipeId, string userId);
        bool DeclineShare(Guid sharedRecipeId, string userId);
    }
}
