﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository;
using RecipeBook.Repository.Interface;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeBook.Service.Implementation
{
    public class ReviewService : IReviewService
    {
        private readonly IRepository<Review> _reviewRepository;

        public ReviewService(IRepository<Review> reviewRepository)
        {
            _reviewRepository = reviewRepository;
        }

        public List<Review> GetAllByRecipe(Guid recipeId)
        {
            return _reviewRepository.GetAll(predicate: r => r.RecipeId == recipeId).ToList();
        }

        public Review GetById(Guid id)
        {
            return _reviewRepository.Get(predicate: r => r.Id == id);
        }

        public Review Create(Review review)
        {
            review.CreatedAt = DateTime.UtcNow;
            return _reviewRepository.Insert(review);
        }

        public Review Update(Review review)
        {
            return _reviewRepository.Update(review);
        }

        public Review Delete(Guid id)
        {
            var review = _reviewRepository.Get(predicate: r => r.Id == id);
            if (review == null)
                throw new ArgumentException($"Review with id {id} not found.");

            return _reviewRepository.Delete(review);
        }

        public double GetAverageRatingForRecipe(Guid recipeId)
        {
            var reviews = _reviewRepository.GetAll(predicate: r => r.RecipeId == recipeId);

            if (!reviews.Any())
                return 0;

            return reviews.Average(r => r.Rating);
        }
    }
}
