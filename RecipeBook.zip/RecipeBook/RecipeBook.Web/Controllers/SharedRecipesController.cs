﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;

namespace RecipeBook.Web.Controllers
{
    [Authorize]
    public class SharedRecipesController : Controller
    {
        private readonly ISharedRecipeService _sharedRecipeService;

        public SharedRecipesController(ISharedRecipeService sharedRecipeService)
        {
            _sharedRecipeService = sharedRecipeService;
        }

        // Прикажи сите споделени рецепти за тековниот корисник
        public IActionResult Index()
        {
            var userId = User.Identity?.Name; // Или земи userId од claim, според имплементацијата
            if (userId == null)
                return Unauthorized();

            var sharedRecipes = _sharedRecipeService.GetSharedRecipesForUser(userId);
            return View(sharedRecipes);
        }

        // Прикажи детали за споделен рецепт
        public IActionResult Details(Guid id)
        {
            var sharedRecipe = _sharedRecipeService.GetSharedRecipesForUser(User.Identity?.Name)
                                   .Find(sr => sr.Id == id);

            if (sharedRecipe == null)
                return NotFound();

            return View(sharedRecipe);
        }

        // Форма за споделување рецепт со друг корисник
        [HttpGet]
        public IActionResult ShareRecipe(Guid recipeId)
        {
            ViewBag.RecipeId = recipeId;
            return View();
        }

        // Постави споделување на рецепт (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ShareRecipe(Guid recipeId, string sharedWithUserId)
        {
            var sharedByUserId = User.Identity?.Name;
            if (sharedByUserId == null)
                return Unauthorized();

            var sharedRecipe = _sharedRecipeService.ShareRecipe(recipeId, sharedByUserId, sharedWithUserId);
            return RedirectToAction(nameof(Index));
        }

        // Прифати споделен рецепт
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AcceptShare(Guid sharedRecipeId)
        {
            var userId = User.Identity?.Name;
            if (userId == null)
                return Unauthorized();

            var success = _sharedRecipeService.AcceptShare(sharedRecipeId, userId);
            if (!success)
                return BadRequest();

            return RedirectToAction(nameof(Index));
        }

        // Одбери споделен рецепт
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeclineShare(Guid sharedRecipeId)
        {
            var userId = User.Identity?.Name;
            if (userId == null)
                return Unauthorized();

            var success = _sharedRecipeService.DeclineShare(sharedRecipeId, userId);
            if (!success)
                return BadRequest();

            return RedirectToAction(nameof(Index));
        }
    }
}
