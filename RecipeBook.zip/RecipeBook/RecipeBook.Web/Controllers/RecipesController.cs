﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecipeBook.Web.Controllers
{
    [Authorize]
    public class RecipesController : Controller
    {
        private readonly IRecipeService _recipeService;
        private readonly IDataFetchService _dataFetchService;
        private readonly IFavouriteRecipeService _favouriteRecipeService;

        public RecipesController(
            IRecipeService recipeService,
            IDataFetchService dataFetchService,
            IFavouriteRecipeService favouriteRecipeService) // <== Додадено!
        {
            _recipeService = recipeService;
            _dataFetchService = dataFetchService;
            _favouriteRecipeService = favouriteRecipeService; // <== Додадено!
        }

        // GET: /Recipes
        public IActionResult Index()
        {
            var recipes = _recipeService.GetAll();

            // Земаме userId од најавениот корисник
            var userId = User.Identity?.Name;
            List<Guid> favouriteRecipeIds = new List<Guid>();

            if (!string.IsNullOrEmpty(userId))
            {
                var favourites = _favouriteRecipeService.GetFavouritesForUser(userId);
                favouriteRecipeIds = favourites.Select(f => f.RecipeId).ToList();
            }

            // Испраќаме ги и двете во ViewModel или ViewBag
            ViewBag.FavouriteRecipeIds = favouriteRecipeIds;

            return View(recipes);
        }

        // GET: /Recipes/Details/{id}
        public IActionResult Details(Guid id)
        {
            var recipe = _recipeService.GetById(id);
            if (recipe == null) return NotFound();
            return View(recipe);
        }

        // GET: /Recipes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Recipes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Name,Category,Area,Instructions,ThumbnailUrl")] Recipe recipe)
        {
            if (!ModelState.IsValid)
            {
                return View(recipe);
            }

            recipe.Id = Guid.NewGuid();
            _recipeService.Create(recipe);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Recipes/Edit/{id}
        public IActionResult Edit(Guid id)
        {
            var recipe = _recipeService.GetById(id);
            if (recipe == null) return NotFound();
            return View(recipe);
        }

        // POST: /Recipes/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Guid id, [Bind("Id,Name,Category,Area,Instructions,ThumbnailUrl")] Recipe recipe)
        {
            if (id != recipe.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(recipe);
            }

            _recipeService.Update(recipe);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Recipes/Delete/{id}
        public IActionResult Delete(Guid id)
        {
            var recipe = _recipeService.GetById(id);
            if (recipe == null) return NotFound();
            return View(recipe);
        }

        // POST: /Recipes/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(Guid id)
        {
            _recipeService.Delete(id);
            return RedirectToAction(nameof(Index));
        }

        // POST: /Recipes/FetchRecipe (Fetch recipe from external API by name)
        [HttpPost]
        public async Task<IActionResult> FetchRecipeByName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                TempData["Error"] = "Внеси име на рецепт.";
                return RedirectToAction(nameof(Index));
            }

            var recipe = await _dataFetchService.FetchAndSaveRecipeByNameAsync(name);
            if (recipe == null)
                TempData["Error"] = $"Рецептот '{name}' не е најден.";
            else
                TempData["Success"] = $"Рецептот '{name}' е успешно повлечен и зачуван.";

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> FetchRecipesByFilter(string? category, string? area)
        {
            var recipes = await _dataFetchService.FetchAndSaveRecipesAsync(category, area);
            TempData["Success"] = $"{recipes.Count} рецепти се успешно повлечени и зачувани.";
            return RedirectToAction(nameof(Index));
        }
    }
}
