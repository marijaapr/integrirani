﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;

namespace RecipeBook.Web.Controllers
{
    [Authorize]
    public class FavouriteRecipesController : Controller
    {
        private readonly IFavouriteRecipeService _favouriteService;
        private readonly UserManager<User> _userManager;

        public FavouriteRecipesController(IFavouriteRecipeService favouriteService, UserManager<User> userManager)
        {
            _favouriteService = favouriteService;
            _userManager = userManager;
        }

        // Прикажи листа со омилени рецепти на корисникот
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var favourites = _favouriteService.GetFavouritesForUser(user.Id);
            return View(favourites);
        }

        // Додај рецепт во омилени
        [HttpPost]
        public async Task<IActionResult> Add(Guid recipeId)
        {
            var user = await _userManager.GetUserAsync(User);
            var favourite = _favouriteService.AddToFavourites(user.Id, recipeId);
            if (favourite != null)
                return RedirectToAction(nameof(Index),"Recipes");

            // Ако има неуспех, врати некоја грешка (може и TempData за порака)
            return BadRequest();
        }

        // Отстрани рецепт од омилени
        [HttpPost]
        public async Task<IActionResult> Remove(Guid recipeId)
        {
            var user = await _userManager.GetUserAsync(User);
            bool removed = _favouriteService.RemoveFromFavourites(user.Id, recipeId);
            if (removed)
                return RedirectToAction(nameof(Index));

            return BadRequest();
        }
    }
}
