﻿using Microsoft.AspNetCore.Identity;
using RecipeBook.Domain.DomainModels;
using System.Collections.Generic;

namespace RecipeBook.Domain.DomainModels
{
    public class User : IdentityUser
    {
        public ICollection<Review> Reviews { get; set; } = new List<Review>();
        public ICollection<FavouriteRecipe> FavouriteRecipes { get; set; } = new List<FavouriteRecipe>();
        public ICollection<SharedRecipe> SharedRecipesReceived { get; set; } = new List<SharedRecipe>();
        public ICollection<SharedRecipe> SharedRecipesSent { get; set; } = new List<SharedRecipe>();
    }
}

