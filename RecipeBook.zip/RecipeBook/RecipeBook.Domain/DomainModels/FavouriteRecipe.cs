﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Domain.DomainModels
{
    public class FavouriteRecipe : BaseEntity
    {
        public string UserId { get; set; }

        [ForeignKey(nameof(Recipe))]
        public Guid RecipeId { get; set; }
        public Recipe Recipe { get; set; }

        public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    }
}
