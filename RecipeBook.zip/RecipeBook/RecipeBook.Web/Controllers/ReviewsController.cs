﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;

namespace RecipeBook.Web.Controllers
{
    [Authorize]
    public class ReviewsController : Controller
    {
        private readonly IReviewService _reviewService;
        private readonly UserManager<User> _userManager;

        public ReviewsController(IReviewService reviewService, UserManager<User> userManager)
        {
            _reviewService = reviewService;
            _userManager = userManager;
        }

        // Прикажи сите ревјуа за даден рецепт
        public IActionResult Index(Guid recipeId)
        {
            var reviews = _reviewService.GetAllByRecipe(recipeId);
            ViewBag.RecipeId = recipeId;
            return View(reviews);
        }

        // Детали за ревју
        public IActionResult Details(Guid? id)
        {
            if (id == null) return NotFound();

            var review = _reviewService.GetById(id.Value);
            if (review == null) return NotFound();

            return View(review);
        }

        // Форма за додавање ревју (Create)
        [HttpGet]
        public IActionResult Create(Guid recipeId)
        {
            var review = new Review { RecipeId = recipeId };
            return View(review);
        }

        // Постави ново ревју
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RecipeId,UserId,UserName,Rating,Comment")] Review review)
        {
            if (!ModelState.IsValid)
                return View(review);

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            review.UserId = user.Id;
            review.UserName = user.UserName;
            review.CreatedAt = DateTime.UtcNow;

            _reviewService.Create(review);

            return RedirectToAction(nameof(Index), new { recipeId = review.RecipeId });
        }

        // Форма за уредување ревју
        [HttpGet]
        public IActionResult Edit(Guid? id)
        {
            if (id == null) return NotFound();

            var review = _reviewService.GetById(id.Value);
            if (review == null) return NotFound();

            return View(review);
        }

        // Постави уредено ревју
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Guid id, [Bind("Id,RecipeId,UserId,UserName,Rating,Comment")] Review review)
        {
            if (id != review.Id) return NotFound();

            if (!ModelState.IsValid)
                return View(review);

            _reviewService.Update(review);
            return RedirectToAction(nameof(Index), new { recipeId = review.RecipeId });
        }

        // Потврда за бришење ревју
        [HttpGet]
        public IActionResult Delete(Guid? id)
        {
            if (id == null) return NotFound();

            var review = _reviewService.GetById(id.Value);
            if (review == null) return NotFound();

            return View(review);
        }

        // Изврши бришење
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(Guid id)
        {
            var review = _reviewService.GetById(id);
            if (review == null) return NotFound();

            _reviewService.Delete(id);
            return RedirectToAction(nameof(Index), new { recipeId = review.RecipeId });
        }

        // Дополителна акција: прикажи просечна оцена за рецепт
        public IActionResult AverageRating(Guid recipeId)
        {
            var average = _reviewService.GetAverageRatingForRecipe(recipeId);
            return Json(new { RecipeId = recipeId, AverageRating = average });
        }
    }
}
