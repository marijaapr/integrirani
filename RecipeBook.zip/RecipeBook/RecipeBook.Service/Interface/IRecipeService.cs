﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface IRecipeService
    {
        List<Recipe> GetAll();
        Recipe GetById(Guid id);
        Recipe Create(Recipe recipe);
        Recipe Update(Recipe recipe);
        Recipe Delete(Guid id);

        // Дополнителни акции
        List<Recipe> GetTopRated(int minRating);
        List<Recipe> SearchByName(string name);
        double GetAverageRating(Guid recipeId);
    }
}
