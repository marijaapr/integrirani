﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Domain.DomainModels.DTOs;
using RecipeBook.Service.Interface;
using System.Net.Http;
using System.Net.Http.Json;
using System.Reflection;

public class DataFetchService : IDataFetchService
{
    private readonly HttpClient _httpClient;
    private readonly IRecipeService _recipeService;

    public DataFetchService(HttpClient httpClient, IRecipeService recipeService)
    {
        _httpClient = httpClient;
        _recipeService = recipeService;
    }

    public async Task<Recipe?> FetchAndSaveRecipeByNameAsync(string name)
    {
        string url = $"https://www.themealdb.com/api/json/v1/1/search.php?s={Uri.EscapeDataString(name)}";
        var response = await _httpClient.GetFromJsonAsync<RecipeResponseDto>(url);

        if (response == null || response.Meals == null || response.Meals.Count == 0)
            return null;

        var mealDto = response.Meals[0];
        var recipe = MapMealDtoToRecipe(mealDto);

        var existing = _recipeService.GetAll().FirstOrDefault(r => r.Name == recipe.Name);
        if (existing != null)
            return existing;

        return _recipeService.Create(recipe);
    }

    public async Task<List<Recipe>> FetchAndSaveRecipesAsync(string? category = null, string? area = null)
    {
        
        string url = "https://www.themealdb.com/api/json/v1/1/search.php?s=";
        var response = await _httpClient.GetFromJsonAsync<RecipeResponseDto>(url);

        if (response == null || response.Meals == null)
            return new List<Recipe>();

        var recipes = new List<Recipe>();
        foreach (var mealDto in response.Meals)
        {
            var recipe = MapMealDtoToRecipe(mealDto);
            var existing = _recipeService.GetAll().FirstOrDefault(r => r.Name == recipe.Name);
            if (existing == null)
            {
                var created = _recipeService.Create(recipe);
                recipes.Add(created);
            }
            else
            {
                recipes.Add(existing);
            }
        }
        return recipes;
    }

    private Recipe MapMealDtoToRecipe(RecipeDto mealDto)
    {
        var recipe = new Recipe
        {
            Id = Guid.NewGuid(),
            Name = mealDto.StrMeal,
            Category = mealDto.StrCategory,
            Area = mealDto.StrArea,
            Instructions = mealDto.StrInstructions,
            ThumbnailUrl = mealDto.StrMealThumb,
            Ingredients = new List<Ingredient>()
        };

        
        for (int i = 1; i <= 20; i++)
        {
            PropertyInfo ingredientProp = typeof(RecipeDto).GetProperty($"StrIngredient{i}");
            PropertyInfo measureProp = typeof(RecipeDto).GetProperty($"StrMeasure{i}");

            var ingredient = ingredientProp?.GetValue(mealDto) as string;
            var measure = measureProp?.GetValue(mealDto) as string;

            if (!string.IsNullOrWhiteSpace(ingredient))
            {
                recipe.Ingredients.Add(new Ingredient
                {
                    Id = Guid.NewGuid(),
                    Name = ingredient.Trim(),
                    Measure = measure?.Trim() ?? "",
                    RecipeId = recipe.Id
                });
            }
        }

        return recipe;
    }
}
