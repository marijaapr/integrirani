﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository;
using RecipeBook.Repository.Interface;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeBook.Service.Implementation
{
    public class SharedRecipeService : ISharedRecipeService
    {
        private readonly IRepository<SharedRecipe> _sharedRecipeRepository;
        private readonly IRepository<Recipe> _recipeRepository;
        private readonly IUserRepository _userRepository;

        public SharedRecipeService(
            IRepository<SharedRecipe> sharedRecipeRepository,
            IRepository<Recipe> recipeRepository,
            IUserRepository userRepository)
        {
            _sharedRecipeRepository = sharedRecipeRepository;
            _recipeRepository = recipeRepository;
            _userRepository = userRepository;
        }

        public List<SharedRecipe> GetSharedRecipesForUser(string userId)
        {
            return _sharedRecipeRepository.GetAll(
                predicate: sr => sr.SharedWithUserId == userId && sr.Status != ShareStatus.Declined
            ).ToList();
        }

        public SharedRecipe ShareRecipe(Guid recipeId, string sharedByUserId, string sharedWithUserId)
        {
            var recipe = _recipeRepository.Get(predicate: r => r.Id == recipeId);
            var sender = _userRepository.GetById(sharedByUserId);
            var receiver = _userRepository.GetById(sharedWithUserId);

            if (recipe == null || sender == null || receiver == null)
                throw new ArgumentException("Invalid recipe or user id");

            var existingShare = _sharedRecipeRepository.Get(
                predicate: sr => sr.RecipeId == recipeId
                                && sr.SharedByUserId == sharedByUserId
                                && sr.SharedWithUserId == sharedWithUserId);

            if (existingShare != null)
            {
                // Ако веќе постои такво споделување, врати го без ново креирање
                return existingShare;
            }

            var sharedRecipe = new SharedRecipe
            {
                Id = Guid.NewGuid(),
                RecipeId = recipeId,
                SharedByUserId = sharedByUserId,
                SharedWithUserId = sharedWithUserId,
                Status = ShareStatus.Pending,
                SharedAt = DateTime.UtcNow
            };

            return _sharedRecipeRepository.Insert(sharedRecipe);
        }

        public bool AcceptShare(Guid sharedRecipeId, string userId)
        {
            var sharedRecipe = _sharedRecipeRepository.Get(
                predicate: sr => sr.Id == sharedRecipeId);

            if (sharedRecipe == null || sharedRecipe.SharedWithUserId != userId)
                return false;

            sharedRecipe.Status = ShareStatus.Accepted;
            _sharedRecipeRepository.Update(sharedRecipe);

            return true;
        }

        public bool DeclineShare(Guid sharedRecipeId, string userId)
        {
            var sharedRecipe = _sharedRecipeRepository.Get(
                predicate: sr => sr.Id == sharedRecipeId);

            if (sharedRecipe == null || sharedRecipe.SharedWithUserId != userId)
                return false;

            sharedRecipe.Status = ShareStatus.Declined;
            _sharedRecipeRepository.Update(sharedRecipe);

            return true;
        }
    }
}
