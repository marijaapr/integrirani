﻿using RecipeBook.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBook.Service.Interface
{
    public interface IReviewService
    {
        List<Review> GetAllByRecipe(Guid recipeId);
        Review GetById(Guid id);
        Review Create(Review review);
        Review Update(Review review);
        Review Delete(Guid id);

        double GetAverageRatingForRecipe(Guid recipeId);
    }
}
