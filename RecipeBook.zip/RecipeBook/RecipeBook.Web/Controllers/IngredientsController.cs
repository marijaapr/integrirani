﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecipeBook.Domain.DomainModels;
using RecipeBook.Service.Interface;
using System;
using System.Linq;

namespace RecipeBook.Web.Controllers
{
    [Authorize]
    public class IngredientsController : Controller
    {
        private readonly IIngredientService _ingredientService;

        public IngredientsController(IIngredientService ingredientService)
        {
            _ingredientService = ingredientService;
        }

        // GET: Ingredients/ByRecipe/{recipeId}
        public IActionResult ByRecipe(Guid recipeId)
        {
            var ingredients = _ingredientService.GetAllByRecipe(recipeId);
            ViewBag.RecipeId = recipeId;
            return View(ingredients);
        }

        // GET: Ingredients/Details/{id}
        public IActionResult Details(Guid id)
        {
            var ingredient = _ingredientService.GetById(id);
            if (ingredient == null)
                return NotFound();

            return View(ingredient);
        }

        // GET: Ingredients/Create?recipeId={recipeId}
        public IActionResult Create(Guid recipeId)
        {
            ViewBag.RecipeId = recipeId;
            return View();
        }

        // POST: Ingredients/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Ingredient ingredient)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.RecipeId = ingredient.RecipeId;
                return View(ingredient);
            }

            _ingredientService.Create(ingredient);
            return RedirectToAction(nameof(ByRecipe), new { recipeId = ingredient.RecipeId });
        }

        // GET: Ingredients/Edit/{id}
        public IActionResult Edit(Guid id)
        {
            var ingredient = _ingredientService.GetById(id);
            if (ingredient == null)
                return NotFound();

            return View(ingredient);
        }

        // POST: Ingredients/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Guid id, Ingredient ingredient)
        {
            if (id != ingredient.Id)
                return BadRequest();

            if (!ModelState.IsValid)
                return View(ingredient);

            _ingredientService.Update(ingredient);
            return RedirectToAction(nameof(ByRecipe), new { recipeId = ingredient.RecipeId });
        }

        // GET: Ingredients/Delete/{id}
        public IActionResult Delete(Guid id)
        {
            var ingredient = _ingredientService.GetById(id);
            if (ingredient == null)
                return NotFound();

            return View(ingredient);
        }

        // POST: Ingredients/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(Guid id)
        {
            var ingredient = _ingredientService.GetById(id);
            if (ingredient == null)
                return NotFound();

            var recipeId = ingredient.RecipeId;
            _ingredientService.Delete(id);
            return RedirectToAction(nameof(ByRecipe), new { recipeId = recipeId });
        }
    }
}
