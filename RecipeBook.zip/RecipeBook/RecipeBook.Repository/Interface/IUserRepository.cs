﻿using RecipeBook.Domain.DomainModels;

using System.Collections.Generic;

namespace RecipeBook.Repository.Interface
{
    public interface IUserRepository
    {
        User? GetById(string id);
        List<User> GetAll();

        
        User? GetByUserName(string username);
        User? GetByEmail(string email);
    }
}
