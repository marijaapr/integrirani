﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository;
using RecipeBook.Repository.Interface;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeBook.Service.Implementation
{
    public class IngredientService : IIngredientService
    {
        private readonly IRepository<Ingredient> _ingredientRepository;

        public IngredientService(IRepository<Ingredient> ingredientRepository)
        {
            _ingredientRepository = ingredientRepository;
        }

        public List<Ingredient> GetAllByRecipe(Guid recipeId)
        {
            return _ingredientRepository.GetAll(predicate: i => i.RecipeId == recipeId).ToList();
        }

        public Ingredient GetById(Guid id)
        {
            return _ingredientRepository.Get(predicate: i => i.Id == id);
        }

        public Ingredient Create(Ingredient ingredient)
        {
            if (ingredient.Id == Guid.Empty)
                ingredient.Id = Guid.NewGuid();

            return _ingredientRepository.Insert(ingredient);
        }

        public Ingredient Update(Ingredient ingredient)
        {
            return _ingredientRepository.Update(ingredient);
        }

        public Ingredient Delete(Guid id)
        {
            var ingredient = _ingredientRepository.Get(predicate: i => i.Id == id);
            if (ingredient == null)
                throw new ArgumentException($"Ingredient with id {id} not found.");

            return _ingredientRepository.Delete(ingredient);
        }
    }
}
