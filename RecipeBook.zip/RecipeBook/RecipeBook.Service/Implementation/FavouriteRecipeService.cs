﻿using RecipeBook.Domain.DomainModels;
using RecipeBook.Repository;
using RecipeBook.Repository.Interface;
using RecipeBook.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace RecipeBook.Service.Implementation
{
    public class FavouriteRecipeService : IFavouriteRecipeService
    {
        private readonly IRepository<FavouriteRecipe> _favouriteRecipeRepository;
        private readonly IRepository<Recipe> _recipeRepository;

        public FavouriteRecipeService(
            IRepository<FavouriteRecipe> favouriteRecipeRepository,
            IRepository<Recipe> recipeRepository)
        {
            _favouriteRecipeRepository = favouriteRecipeRepository;
            _recipeRepository = recipeRepository;
        }

        public List<FavouriteRecipe> GetFavouritesForUser(string userId)
        {
            return _favouriteRecipeRepository.GetAll(
                predicate: fr => fr.UserId == userId,
                include: q => q.Include(fr => fr.Recipe))
                .ToList();
        }

        public FavouriteRecipe AddToFavourites(string userId, Guid recipeId)
        {
            var existing = _favouriteRecipeRepository.Get(
                predicate: fr => fr.UserId == userId && fr.RecipeId == recipeId);

            if (existing != null)
            {
                // Веќе е во омилени, врати го постоечкиот запис
                return existing;
            }

            var recipe = _recipeRepository.Get(predicate: r => r.Id == recipeId);
            if (recipe == null)
                throw new ArgumentException("Invalid recipeId");

            var favourite = new FavouriteRecipe
            {
                Id = Guid.NewGuid(),
                UserId = userId,
                RecipeId = recipeId,
                AddedAt = DateTime.UtcNow
            };

            return _favouriteRecipeRepository.Insert(favourite);
        }

        public bool RemoveFromFavourites(string userId, Guid recipeId)
        {
            var favourite = _favouriteRecipeRepository.Get(
                predicate: fr => fr.UserId == userId && fr.RecipeId == recipeId);

            if (favourite == null)
                return false;

            _favouriteRecipeRepository.Delete(favourite);
            return true;
        }
    }
}
